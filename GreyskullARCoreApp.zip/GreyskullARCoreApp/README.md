# Greyskull ARCore Capture Starter Project

This is a minimal Android app starter for the Greyskull / G-POSE style 3D capture idea.
It starts ARCore on a Samsung S26 Ultra (or any ARCore phone) so the camera + depth sensor can be used.

## How to build and install (for your friend)

1. Download and install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder and open it in Android Studio (File > Open).
3. Let Android Studio download any missing tools (SDK, ARCore).
4. Connect the phone with USB (turn on Developer Options + USB Debugging) or:
   - Build > Build Bundle(s)/APK(s) > Build APK(s)
5. The APK appears in app/build/outputs/apk/debug/
6. Copy the APK to the phone and tap it to install. 
   (This is called sideloading — just allow the install when Android asks.)

This version shows a message and starts the ARCore session. 
It is the foundation for adding depth capture and pose refinement later.

Project context: Independent multi-view camera pose recovery to improve 3D reconstruction accuracy from phone depth scans.
