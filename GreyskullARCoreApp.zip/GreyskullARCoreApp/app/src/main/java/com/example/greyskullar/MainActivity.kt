package com.example.greyskullar

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Session
import com.google.ar.core.exceptions.UnavailableException
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class MainActivity : AppCompatActivity() {
    private var session: Session? = null
    private lateinit var surfaceView: GLSurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        surfaceView = GLSurfaceView(this)
        surfaceView.setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {}
            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {}
            override fun onDrawFrame(gl: GL10?) {
                // Simple placeholder rendering loop
                // Real version would draw the point cloud here
            }
        })
        setContentView(surfaceView)

        try {
            if (ArCoreApk.getInstance().requestInstall(this, true) != ArCoreApk.InstallStatus.INSTALLED) {
                return
            }
            session = Session(this)
            val config = Config(session)
            config.depthMode = Config.DepthMode.AUTOMATIC
            config.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
            session?.configure(config)
            Toast.makeText(this, "ARCore ready — move around an object", Toast.LENGTH_LONG).show()
        } catch (e: UnavailableException) {
            Toast.makeText(this, "ARCore not available: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        session?.resume()
    }

    override fun onPause() {
        super.onPause()
        session?.pause()
    }

    // Placeholder for the G-POSE style multi-view pose refinement
    // Later: collect depth frames + poses, run the optimizer from the Python prototype,
    // then update the point cloud display.
    private fun refinePoses(frames: List<Frame>) {
        // TODO: port the multi-view point-to-plane optimizer here
    }
}
